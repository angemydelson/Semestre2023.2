#include<stdio.h>


void main(){

     printf("\n Now I am a different program/process YEEEEEEEEEEEEEEEEEEEPPPPP\n");
     for(;;);


}
